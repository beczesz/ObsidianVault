# Wireframes — Deák Húsmíves Online Platform

## Mi ez?

Ez a mappa tartalmazza a DH platform összes wireframe-jét. Minden wireframe önálló HTML fájl, amely böngészőben megnyitható — nincs szükség külön szerverre vagy build lépésre.

## Élő előnézet (Netlify)

**Wireframe galéria:** [https://deakhus.netlify.app](https://deakhus.netlify.app)

A Netlify site automatikusan a mappa tartalmát tükrözi. Az `index.html` egy böngészhető katalógust mutat az összes wireframe-ről, Deák Húsmíves brandben.

**Netlify admin:** [https://app.netlify.com/projects/deakhus](https://app.netlify.com/projects/deakhus)

## Fájlstruktúra

```
wireframes/
├── index.html                          ← Wireframe galéria (Netlify főoldal)
├── README.md                           ← Ez a fájl
├── v0.3-wireframes-v3.html            ← v0.3 Savings Engine wireframes (legfrissebb)
├── v0.3-wireframes-v2.html            ← v0.3 korábbi verzió
├── butcher-courier-wireframe-v3.html  ← Mészáros + futár felületek
├── contul-meu-admin-switcher.html     ← Contul meu + admin switcher
├── wireframe_login.html               ← Login wireframe
├── wireframe_quantity_selector_v2.html ← Mennyiségválasztó v2
├── wireframe_quantity_selector.html    ← Mennyiségválasztó v1
└── archive/                           ← Korábbi verziók
    ├── v0.3-wireframes-v1.html
    └── v0.3-wireframes-v2.html
```

## Hogyan dolgozunk a wireframe-ekkel?

### 1. Áttekintés
Nyisd meg a [https://deakhus.netlify.app](https://deakhus.netlify.app) oldalt, vagy az `index.html`-t lokálisan. Ez mutatja az összes wireframe-et leírással és verzióval.

### 2. Wireframe szerkesztés
Minden wireframe önálló HTML fájl. Szerkesztéshez:
- Cowork-ben: kérd Claude-ot, hogy módosítsa a wireframe-et
- Manuálisan: nyisd meg bármilyen szövegszerkesztővel

### 3. Deploy Netlify-ra
A wireframe mappa tartalma közvetlenül deployolható a Netlify-ra:
- **Manuálisan:** Netlify admin → Deploys → drag & drop a mappa
- **Coworkből:** Claude készít egy deploy-ready zip-et az outputs mappába, amit a Netlify drag & drop felületére húzhatsz

### 4. Új wireframe hozzáadása
1. Készítsd el az új HTML fájlt ebben a mappában
2. Frissítsd az `index.html` galériát (vagy kérd Claude-ot)
3. Deploy Netlify-ra

## Verziózás

| Wireframe | Verzió | Utolsó frissítés | Sprint |
|-----------|--------|-------------------|--------|
| v0.3 Savings Engine | v3 | 2026-04-04 | Sprint 3 (future) |
| Mészáros + Futár | v3 | 2026-03 | Sprint 2 |
| Contul meu / Admin switcher | v1 | 2026-03 | Sprint 2 |
| Login | v1 | 2026-03 | Sprint 1 |
| Quantity Selector | v2 | 2026-03 | Sprint 2 |

## Design alapok

A wireframe-ek a DH Design System-et követik:
- **Fő szín:** `#9B2335` (burgundi vörös)
- **Háttér:** `#FAF7F4` (meleg szürke)
- **Font:** Inter / system-ui
- **Border radius:** 16px (kártyák), 12px (inputok)
- Részletek: `design/design-system.md`
