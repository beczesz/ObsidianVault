---
title: Business Model Canvas – Deák Húsmíves Online Platform (Pilot)
version: 0.5
date: 2026-03-05
author: Becze Szabolcs – Exar Labs
description: BMC for the online ordering pilot — co-venture model where Exar Labs owns platform, marketing, and business development (funded from own capital); butcher shop owns production, quality, and delivery; return via revenue share. v0.5: heading/version consistency fix; Google OAuth as primary auth; hypothesis validation methods added; post-pilot scaling path added.
---

# Business Model Canvas v0.5 – Deák Húsmíves Online Platform (Pilot)

_Version: 0.5 | Last updated: 2026-03-05_
_Scope: This BMC models the online ordering pilot channel only — not the full butcher shop operation. The goal is market validation and learning, not immediate profit maximization._

---

## 1. Customer Segments

Since there is currently no data about existing customers, the pilot will also map which online buyer profile responds strongest.

**Hypothetical segments:**

| Segment | Profile | Motivation |
|---------|---------|------------|
| Family households | Age 30–55, cook regularly, buy 2–5 kg | Convenient weekly/bi-weekly shopping, home delivery |
| Quality-conscious buyers | Health-aware, seek additive-free, local products | Freshness, no preservatives, trust in local producer |
| Time-poor working families | Limited time for in-store shopping | Time saving, predictable ordering |
| Early digital adopters | Open to new purchasing channels | Trying new digital services |

Product is **not premium** — broad potential across the full ~30,000 resident population of Székelyudvarhely.

Purchase type: **planned** (weekly/bi-weekly), not impulse.

---

## 2. Value Proposition

### For the end customer:
- **Freshness** — meat processed the same day, maximum freshness guaranteed
- **Additive-free** — artisan, no preservatives
- **Local trust** — ordering from a known local business
- **Convenience** — order from home, no parking, no queuing
- **Home delivery** — within 24 hours
- **Guaranteed availability** — secure preferred quantities in advance

### For the butcher shop (co-venture partner):
- New revenue channel with **zero upfront investment and zero operational burden** — they only need to produce and deliver
- Better inventory planning (pre-orders reduce waste)
- Access to customer data and buying behavior (currently none exists)
- Financial visibility — first time they'll have real sales statistics
- Professional marketing handled entirely by Exar Labs — no skill or budget required from them

---

## 3. Channels

| Channel | Role |
|---------|------|
| Mobile-first webapp | Primary ordering interface |
| In-store QR code | Key acquisition channel — converts existing foot traffic |
| Facebook page | Communication, promotions, order info |
| Word of mouth | High-trust local community — fast organic spread |

---

## 4. Customer Relationships

**Frictionless onboarding** is critical for pilot success — registration must be completable in 30–60 seconds.

- Google OAuth (primary); Facebook OAuth **optional / post-MVP**
- Email + password (fallback)
- Data collected: name, phone number, delivery address

**Ongoing relationship:**
- Direct feedback from first buyers (they are quasi beta testers)
- Regular Facebook posts: fresh cuts, new products, order info
- Personal and direct tone — this is a local, trusted brand

---

## 5. Revenue Streams

**Co-venture revenue share** — X% of online turnover goes to Exar Labs.

This is not a service fee — it's a return on Exar Labs' investment in the platform, marketing, and business development. The butcher shop pays nothing; Exar Labs earns only when the channel generates revenue.

The model is viable because:
- AI tools reduce development cost to ~1/5 of traditional
- Bench capacity is already paid for (idle cost absorbed)
- Exar Labs controls the marketing lever — growth is not dependent on the client's ability

**Pilot payment method:** Cash on delivery (no payment gateway in v1 — reduces complexity).

**Future:** Online payment gateway integration (post-pilot validation).

---

## 6. Key Resources

| Resource | Owner |
|----------|-------|
| Digital platform (webapp) | Exar Labs |
| Marketing budget & execution | Exar Labs |
| Dev team (bench capacity) | Exar Labs |
| Business development & analytics | Exar Labs |
| Meat processing infrastructure | Butcher shop |
| Delivery vehicle + cold chain | Butcher shop |
| Local brand trust & product quality | Butcher shop |

---

## 7. Key Activities

| Activity | Owner |
|----------|-------|
| MVP development and maintenance | Exar Labs |
| Marketing strategy, content, and paid campaigns | Exar Labs |
| Pilot measurement, analytics, and reporting | Exar Labs |
| Customer support | Exar Labs |
| Product catalog management (uploads, pricing) | Exar Labs (with butcher shop input) |
| Meat processing and packaging | Butcher shop |
| Order delivery | Butcher shop |
| Product quality assurance | Butcher shop |

---

## 8. Key Partners

| Partner | Contribution |
|---------|-------------|
| Deák Húsmíves (butcher shop) | Product, production, delivery infrastructure |
| Local community | First buyers, word-of-mouth validation |
| Facebook | Marketing channel |
| Google / Apple | OAuth authentication providers |

---

## 9. Cost Structure

All costs are borne by **Exar Labs** from own capital. The butcher shop has zero financial obligation.

| Cost | Amount | Frequency | Bearer |
|------|--------|-----------|--------|
| MVP development | Internal bench capacity | One-time | Exar Labs |
| Hosting | ~200 EUR | Annual | Exar Labs |
| Support & maintenance | ~3,000 EUR | Annual | Exar Labs |
| Customer service | ~500 EUR | Annual | Exar Labs |
| Payment gateway | ~200 EUR | Annual (post-pilot) | Exar Labs |
| **Total operating cost** | **~3,900 EUR** | **Annual** | **Exar Labs** |
| Facebook & online advertising | TBD — pilot budget cap to be set | Per campaign | Exar Labs |

---

## Pilot Hypotheses

| ID | Hypothesis | Validation Method | Success Signal |
|----|-----------|------------------|---------------|
| H1 | There is demand for online meat ordering in Székelyudvarhely | 30-day pilot: count orders placed | ≥15 orders in 30 days |
| H2 | Customers are willing to order fresh meat online | 30-day pilot: count completed registrations | ≥30 registrations in 30 days |
| H3 | Average basket value online will be higher than in-store | Compare avg online order value to known in-store avg | Online avg basket ≥ 20% higher |
| H4 | A portion of customers will become repeat buyers | Track customers with ≥2 orders in pilot window | ≥5 returning customers in 30 days |
| H5 | The QR code in-store is the most effective acquisition channel | UTM tracking per channel (QR, Facebook post, word-of-mouth) | QR accounts for ≥40% of registrations |

---

## Pilot Success Metrics (30 days)

| Metric | Target |
|--------|--------|
| Registrations | 30 |
| Orders placed | 15 |
| Returning customers | 5 |

---

## Pilot Constraints (Intentional)

| Constraint | Reason |
|-----------|--------|
| 1 store only | Minimize complexity |
| Cash on delivery only | No payment gateway needed |
| Webapp only (no native app) | Faster to build and deploy |
| Defined marketing budget cap | Control Exar Labs' total investment exposure |

Goal: **fast learning with controlled, predictable investment**.

---

## MVP Product Design

### Mobile-First Principle
80–90% of traffic expected from mobile. Requirements: responsive webapp, fast load, simple one-handed use, large touch targets, minimalist UI. Desktop works but UX is optimized for mobile.

### Order Flow
1. **Browse** — products, select quantity (kg), add to cart
2. **Cart review** — items, quantities, estimated total (may vary slightly after weighing)
3. **Delivery details** — name, phone, address
4. **Place order** → enters system with status: New Order

### Order Status Lifecycle
`New Order` → `Processing` → `Ready for Delivery` → `Out for Delivery` → `Delivered` → `Closed`

### Courier Interface (Mobile)
- View today's deliveries
- Customer name, phone, address, items ordered
- Launch navigation (Google Maps)
- Update order status
- Mark as "Delivered"

### Super Admin Interface
- **Orders:** all orders, status, basket value
- **Customers:** registered users, order history
- **Products:** upload, pricing, availability
- **Statistics:** registrations, order count, basket value, returning customers

This interface is the **pilot measurement and analytics hub**.

---

## Pilot Learning Goals

The system's purpose is not just order management — it's **collecting data on consumer behavior**.

Key learning questions:
- Will people order fresh meat online?
- At what basket value?
- At what frequency?
- Which acquisition channel works best?

The pilot's success is defined by the **speed and quality of market feedback it generates**.

---

## Post-Pilot Scaling Path

If pilot validates (H1 + H2 + H4 all confirmed):

1. **Optimize** — improve UX based on real user feedback, add online payment gateway
2. **Scale** — expand to all 3 butcher shop locations; increase marketing spend
3. **Replicate** — apply the same template to 2–3 other local artisan businesses (bakery, dairy, etc.)
4. **Platform** — evolve toward a **Local Artisan Commerce Platform** serving multiple vendors

If pilot partially validates: analyze which hypotheses failed, adjust one variable (e.g., different marketing channel, different product category), run second 30-day cycle.

---

## Open Questions

> ⚠️ Items 1–5 are **blockers** — must be resolved before launch.

1. Revenue share exact percentage — what is fair given Exar Labs covers all costs and marketing? **[BLOCKER]**
2. What is the total pilot budget cap (marketing + operating)? **[BLOCKER]**
3. What is the go/no-go threshold — when do we decide to scale or stop? **[BLOCKER]**
4. How are complaints and returns handled operationally? **[BLOCKER]**
5. What written agreement is needed to formalize the partnership? **[BLOCKER]**
6. Which marketing message resonates most (freshness? convenience? local trust?)? — can be A/B tested during pilot
