---
from: mihaela.ionescu@contabilpro.ro
to: kovacs.marton.to@gmail.com
date: 2025-03-03 09:15
subject: "Re: Pénzügyi adatok — AFM pályázat"
attachments:
  - bilant_TransOffice_2023_2024.xlsx
---

Szia Márton,

Épp Görögbe indultam a családdal, de gyorsan összedobtam a számokat. Csatolom az Excelt, benne van minden: bilanț, eredménykimutatás, EBITDA, létszám. Ha valami nem tiszta, jövő hét szerdától vagyok újra, de addig is nézd meg, szerintem benne van ami a pályázathoz kell.

Mihi
