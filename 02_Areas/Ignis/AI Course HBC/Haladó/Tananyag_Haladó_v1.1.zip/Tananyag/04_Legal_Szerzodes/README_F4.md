# F4 — Multi-persona kommunikáció
**Időkeret:** 37 perc · **Fázis a workshopban:** 4/6

## Modell

🎤 **3 DEMO** az oktatótól + ⏸ **2 stáció** közöttük.

| # | Fájl | Típus | Idő |
|---|---|---|---|
| **4.1** | `Feladat_4.1_Legal_szerzodes_check.md` | ⏸ STÁCIÓ (Béla bácsi válasz) | ~4p |
| **4.2** | `Feladat_4.2_Penzugyi_email_Excel.md` | ⏸ STÁCIÓ (EBITDA margin) | ~3p |
| **4.3** | `Feladat_4.3_CEO_update_PPT.md` | 🎤 OKTATÓI DEMO (figyelés) | ~6p |

A workshop **drámai csúcsa**: a Béla bácsi cross-document felfedezés (oktatói DEMO) → a résztvevők stációja (Márton válasza Béla bácsi köszönő-emailjére).

## Narratív összefoglaló

3 ember, 3 stílus:
- **Legal (Béla bácsi):** bérleti szerződés deep-check → cross-doc red flag → tisztázó email → válasz + vételi opció
- **Pénzügy (Mihaela):** román email → Excel értelmezés → EBITDA margin számítás
- **CEO (Márton):** 5-slide PPT az állásról

Az AI mint **multi-persona kommunikátor és operátor**.

## Otthoni bónuszok

| # | Bónusz | Output |
|---|---|---|
| 4.4 | `Feladat_4.4_Bonusz_Sajat_szerzodes.md` | Saját szerződés deep-check |
| 4.5 | `Feladat_4.5_Bonusz_Email_hangnem.md` | Ugyanaz az email 3 hangnemben |
| 4.6 | `Feladat_4.6_Bonusz_Excel_dashboard.md` | Excelből vezetői dashboard |
| 4.7 | `Feladat_4.7_Bonusz_Prezi_celkozonseg.md` | Prezentáció 3 célközönségnek |

## Átmenet F5-be

*„Márton látta a PPT-t, rábólintott: pályázunk. Most jön a WOW — a pályázat **össze fog állni 35 perc alatt**."*

**Verzió:** 2.0
