# Monthly Update Brief Template

This template is filled in by Cowork after Phase 1. The completed brief is pasted into Claude for Excel to drive the Phase 2 dashboard update.

---

## How to Use

1. Cowork processes Phase 1 (activity report -> _base.xlsx + _tam.xlsx)
2. Cowork reads the previous month's T&M Raw from the dashboard
3. Cowork compares and generates one block per project (see format below)
4. User copies the brief into Claude for Excel chat
5. Claude for Excel processes projects one by one using the `cps-dashboard-update-v0.1` skill

---

## Brief Header

```markdown
# CPS Monthly Update Brief

**Period:** [YYYY] [Month Name] (Month [MM])
**Generated:** [date]
**Source:** activityreport_[YYYY]_[MM]_base.xlsx
**Dashboard:** CPS - Dashboard - v2.xlsx
**Previous month rows:** [row range in T&M Raw, e.g., 620-664]
**Next empty row:** [first empty row in T&M Raw]
**Total CPS hours this month:** [number]
**Total projects:** [number]
**New projects:** [number or "none"]
**Dropped projects:** [number or "none"]

---
```

## Per-Project Block

One block per project. Projects are ordered: continuing first (alphabetical), then new, then dropped.

```markdown
### [Project Name] -- [Client]

**Action:** CARRY_FORWARD
**Type:** [T&M / Fixed Price / Hybrid / Retainer / Fix Service / Internal]

| Person | E-level | Emp Status | Hours | Daily Rate | Billable | Discount | Fixed | Notes |
|--------|---------|------------|-------|------------|----------|----------|-------|-------|
| Kovacs Attila | e6 | Employee | 160 | 310 | Billable | 0 | 0 | |
| Peidl Gergely | e7 | Employee | 40 | 571 | Billable | 0 | 0 | |

**vs Previous Month:**
- Kovacs Attila: 80h -> 160h (rate unchanged)
- Peidl Gergely: 40h -> 40h (unchanged)

**Flags:** none
```

## Action Types

| Action | Meaning | What Claude for Excel does |
|--------|---------|---------------------------|
| CARRY_FORWARD | Project continues, people may differ | Copy structure, update hours/month |
| NEW_PROJECT | First time this project appears | Create rows from scratch, ask user for missing data |
| NEW_PERSON | Existing project, new person added | Add row for new person, copy project context from others |
| DROPPED | Project was active last month, zero hours now | Do NOT add rows. Flag for user to verify |

## Flag Types

| Flag | Meaning | Action needed |
|------|---------|---------------|
| none | Everything looks normal | Standard write |
| rate_change | Rate differs from previous month | Ask user to confirm new rate |
| new_person | Person not seen before on any project | Ask user for E-level and rate |
| dropped_person | Person was on project last month, missing now | Note in AD, no row needed |
| hours_anomaly | Hours significantly different from average | Note in AD, ask user to verify |
| type_change | Project type changed (e.g., T&M -> Fixed) | Ask user to confirm |

## Service Income Section (after all projects)

```markdown
## Service Income Updates

| Client | Project | Type | Fix Price | Currency | Rate | Currency | Overage Hours | Notes |
|--------|---------|------|-----------|----------|------|----------|---------------|-------|
| MVMI | MVMI Omni Support | Fixed Price | 1200000 | HUF | 0 | | 0 | unchanged |

**New contracts:** none
**Price changes:** none
```

## Special Sections (only when applicable)

```markdown
## Actual PSIC
[Only if there are indirect costs this month]
| Client | Project | Developer | Type | Amount | Currency |
|--------|---------|-----------|------|--------|----------|

## Planned EDC
[Only if contractor costs apply]
| Developer | Amount | Currency | Notes |
|-----------|--------|----------|-------|
| Banfi Istvan | 1800 | EUR | standard monthly |

## CPS Team Changes
[Only if team composition changed]
- New: [name, role]
- Left: [name, reason]
- New team size: [N]
- New avg experience: [X years]
```

## End of Brief

```markdown
---
**Summary:** [N] projects to update, [M] new rows expected, [flags count] flags to review.
**Estimated duration:** [X] minutes at ~2 min per project.
```
