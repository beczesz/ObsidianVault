---
name: cps-dashboard-update-v0.1
description: >
  Updating the CPS Dashboard Excel workbook with monthly data. Triggers:
  "update dashboard", "Phase 2", "dashboard update", "T&M Raw update",
  "service income update", "havi dashboard", "projekt frissites",
  "write to dashboard", "prefill dashboard".
version: 0.1.0
---

# CPS Dashboard Monthly Update (Phase 2)

Update `CPS - Dashboard - v2.xlsx` with new monthly data from Phase 1 statistics.

## How This Works

This is an interactive, project-by-project workflow. The user (Szabolcs) reviews and approves each change before it is committed. Never bulk-write without approval.

**Two environments use this skill:**

1. **Cowork (desktop)** -- reads Phase 1 outputs, compares with previous month, generates a Monthly Update Brief for each project
2. **Claude for Excel (browser add-in)** -- receives the brief, walks through projects one by one, writes cells directly into the open workbook

## Architecture

```
Phase 1 (Cowork)          Phase 2 (Claude for Excel)
--------------------      --------------------------
_base.xlsx                CPS Dashboard open in browser
_tam.xlsx                 
      |                         |
      v                         v
Monthly Update Brief  -->  Paste into Excel chat
(markdown per project)     Claude reads current sheet
                           Proposes changes
                           User ACKs
                           Claude writes cells
                           Changes visible immediately
```

## The Monthly Update Brief

Cowork generates this after Phase 1. It is a structured markdown block per project. Paste it into the Claude for Excel chat to start the update session.

Format per project:

```
### [Project Name] -- [Client]

**Action:** CARRY_FORWARD | NEW_PERSON | DROPPED | NEW_PROJECT
**Month:** YYYY MM (e.g., 2026 4)
**Type:** T&M | Fixed Price | Hybrid | Retainer | Fix Service | Internal

| Person | E-level | Hours | Rate | Billable | Discount | Notes |
|--------|---------|-------|------|----------|----------|-------|
| Kovacs Attila | e6 | 160 | 310 | Billable | 0 | hours up from 80 |
| Peidl Gergely | e7 | 40 | 571 | Billable | 0 | unchanged |

**Previous month comparison:**
- Kovacs Attila: was 80h -> now 160h (rate unchanged)
- Peidl Gergely: was 40h -> now 40h (unchanged)

**Flags:** none | rate_change | new_person | dropped_person | hours_anomaly
```

## Dashboard Structure

The workbook has 26 sheets. The 5 input sheets that need monthly updates:

| Sheet | What | Update frequency |
|-------|------|-----------------|
| T&M Raw | One row per person-project-month (hours, rates, billing) | Every month |
| Service Income | One row per client-project-month (invoiced revenue) | Every month |
| Actual PSIC | Project-specific indirect costs | Only when applicable |
| Planned EDC | External direct costs (contractor fees) | Only when applicable |
| CPS Team | Team composition snapshot | Only when team changes |

All other sheets are formula-driven summaries (CPS Dash V2, BU Dash1, BU Dash2, etc.).

## Step 1: T&M Raw Update

This is the main step, done for every project.

### Column Map (A through AD)

**Columns to write (manual input):**

| Col | Name | Example | Notes |
|-----|------|---------|-------|
| A | Year | 2026 | Integer |
| B | Month | 4 | Integer 1-12 |
| C | Date ID | (formula) | `=A & " " & CHOOSE(B, "January", ...)` |
| D | #Month | #04 April | Format: `#MM MonthName` |
| E | Client | Jumio | From brief |
| F | Project | Jumio AWS | From brief |
| G | Type | T&M | From Clients sheet or brief |
| H | Name | Kovacs Attila | Person name |
| I | Emp. Status | Employee | Employee or Contractor |
| J | Seniority level | e6 | e1 through e9 |
| K | Raported hours | 160 | From brief |
| L | Suggested Daily Rate | | Usually blank |
| M | Daily Rate | 310 | From brief (EUR) |
| N | Rate | (formula) | `=IF(K=0, 0, M/8)` |
| O | Fixed | 0 | Fixed price amount, usually 0 for T&M |
| P | Is Billable | Billable | Billable / Non billable / Internal / On Transfer Price |
| Q | Discount | 0 | 0 or percentage |

**Columns with formulas (copy pattern from row above):**

| Col | Name | Formula template |
|-----|------|-----------------|
| R | Value | `=K*N+O` |
| S | Invoiced | Complex IF -- see reference |
| T | TP | VLOOKUP to Transfer Prices |
| U | Cost Share | IF with K and T |
| V | Normalized Profit | `=N*Utils!$B$14+T` |
| W | Margin | `=IF(N<>0, V/(N*Utils!$B$14), "NA")` |
| X | Project | `=F` (copy of project) |

**State tracking columns (our addition):**

| Col | Name | Values |
|-----|------|--------|
| AC | Status | PREFILLED / ACK / REVIEW / ADJUSTED / SKIP |
| AD | Notes | Free text context |

### How to Add Rows

1. Find the last used row in T&M Raw
2. For each person in the brief, add a new row below
3. Fill columns A-Q with values from the brief
4. For formula columns (C, N, R-X): copy the formula from the row above and adjust the row reference
5. Set AC = "PREFILLED"
6. Set AD = any notes from the brief (e.g., "hours up from 80", "new person")

### State Definitions

| State | Meaning | Who sets it |
|-------|---------|-------------|
| PREFILLED | Claude added these rows, not yet reviewed | Claude |
| ACK | Reviewed and confirmed by Szabolcs | Szabolcs (via chat) |
| REVIEW | Something unclear, needs discussion | Either |
| ADJUSTED | Was ACK'd but then manually corrected | Szabolcs |
| SKIP | Intentionally excluded this month | Szabolcs |

### Interaction Pattern (Claude for Excel)

For each project in the brief:

1. **Announce:** "Next: [Project] -- [Client]. Adding [N] rows for [person list]. Ready?"
2. **Wait for ACK** from user in chat
3. **Write rows** with Status = PREFILLED
4. **Report:** "Written [N] rows (rows X-Y). Status: PREFILLED. Please verify in the sheet."
5. **User verifies** visually in the spreadsheet
6. **User ACKs** in chat -> update Status column from PREFILLED to ACK
7. **Move to next project**

If user says "review" or flags an issue, set Status = REVIEW and note the concern in AD.

## Step 2: Service Income Update

After all T&M Raw projects are done.

**When:** For each active project that month, ensure a Service Income row exists.

**Columns:** A (Year), B (Month), C (Date ID formula), D (Client), E (Project), F (Type), G-J (fix price and rate in original currency), K-L (EUR formulas), M-N (overage), O (overage formula), P (revenue formula), Q-W (profitability formulas).

**Process:** The brief includes a Service Income section if there are new projects or price changes. For continuing projects, copy the previous month's row and update Year/Month.

## Step 3: Actual PSIC (if applicable)

Only when there are support overtime, phone service, or availability payments. The brief will explicitly flag this.

## Step 4: Planned EDC (if applicable)

Banfi Istvan's monthly contractor fee. The brief will include the amount if applicable.

## Step 5: CPS Team (if applicable)

Only when team size or composition changed. Brief flags this.

## Step 6: Final Verification

After all writes are done:
1. Check that total hours in new T&M Raw rows match the Phase 1 CPS total
2. Check BU Dash1 -- does the new month appear with correct totals?
3. Check CPS Dash V2 -- contract counts correct?
4. Scan for #REF, #N/A, or obviously wrong numbers
5. Mark all PREFILLED rows as ACK once user confirms

## Resumability

The Status column (AC) in T&M Raw makes any session resumable. On session start:
- Read T&M Raw for the current month
- Rows with ACK = done, skip
- Rows with PREFILLED = need user review
- Projects with no rows yet = not started
- Rows with REVIEW = need discussion first

This means you can close the browser, come back tomorrow, and pick up exactly where you left off.

## Reference Files

See the `references/` folder for:
- `formula-templates.md` -- exact formula strings for all calculated columns
- `column-map.md` -- complete A-AD column reference with data types and validation rules
- `brief-template.md` -- the Monthly Update Brief template that Cowork generates
